# Sitio Web en CSS3
En este repositorio van a poder encontrar los archivos iniciales para poder hacer el sitio web del canal de Youtube. 
Este es el resultado final de nuestro sitio web cuando terminemos los tutoriales

![alt text](https://github.com/marcosrivasr/Sitio-Web-CSS3/blob/master/portada.png)
